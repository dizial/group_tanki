#include <Mappy.hpp>

int main() {

    sf::RenderWindow window(sf::VideoMode(1280, 720), "DieTeR tanks", sf::Style::Default);
    window.setVerticalSyncEnabled(true);

    // ��� �������� ������������ ����-��� �� 5 �� �����
    Mappy mappy;
    mappy.loadMapFromData("1111111\n1001001\n1001001\n1001011\n1011001\n1000001\n1111111");
    mappy.resize(window.getSize().x, window.getSize().y);
    mappy.applyChangingObjects("t1:1x1");
    mappy.applyChangingObjects("t1:1x2;b1:2x2");

    while(window.isOpen()) {

        sf::Event event;
        while(window.pollEvent(event)) {
            if(event.type == sf::Event::Closed || (event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::Escape)) {
                window.close();
            } else if(event.type == sf::Event::Resized) {
                sf::View view = window.getView();
                view.setSize(event.size.width, event.size.height);
                view.setCenter(view.getSize() * 0.5f);
                window.setView(view);
                mappy.resize(event.size.width, event.size.height);
            }
        }

        window.clear();
        window.draw(mappy);
        window.display();

    }

    return 0;

}
