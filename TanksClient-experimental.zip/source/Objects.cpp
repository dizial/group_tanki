#include "Objects.hpp"

/// ---------------- Object --------------------

Object::Object() {
    m_shape.setFillColor({240, 240, 240});
}

void Object::create(int x, int y, int width, int height) {
    m_shape.setPosition(x, y);
    m_shape.setSize({static_cast<float>(width), static_cast<float>(height)});
}

void Object::setPosition(int x, int y) {
    m_shape.setPosition(x, y);
}

Object::~Object() {
    //
}

/// ------------- RenderObject -----------------

RenderObject::RenderObject() {
    //
}

RenderObject::~RenderObject() {
    //
}

/// --------------- Obstacle -------------------

Obstacle::Obstacle() {
    //
}

Obstacle::~Obstacle() {
    //
}

void Obstacle::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    target.draw(m_shape, states);
}

/// ---------------- Panzer --------------------

Panzer::Panzer() {
    m_shape.setFillColor({176, 176, 176});
}

Panzer::~Panzer() {
    //
}

void Panzer::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    target.draw(m_shape, states);
}

/// ---------------- Bullet --------------------

Bullet::Bullet() {
    m_shape.setFillColor({200, 200, 64});
}

void Bullet::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    target.draw(m_shape, states);
}
