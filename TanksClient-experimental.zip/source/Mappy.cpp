#include "Mappy.hpp"

#include <iostream>

Mappy::Mappy() {
    //ctor
}


bool Mappy::loadMapFromData(const std::string& mapData) {

    sf::Vector2i curPosition;
    for(size_t i = 0; i < mapData.size(); ++i) {

        if(mapData[i] == '1') {

            Obstacle* tmp = new Obstacle;
            tmp->create(curPosition.x, curPosition.y, 1, 1);
            m_obstacles.push_back(tmp);

            if(curPosition.x + 1 > m_mapSize.x)
                m_mapSize.x = curPosition.x + 1;
            if(curPosition.y + 1 > m_mapSize.y)
                m_mapSize.y = curPosition.y + 1;

        } else if(mapData[i] == '\r' || mapData[i] == '\n') {
            if(mapData[i + 1] == '\n')
                ++i;
            curPosition.x = -1;
            ++curPosition.y;
        }

        ++curPosition.x;

    }

    return true;
}

bool Mappy::applyChangingObjects(const std::string& changingObjects) {

    // Description of the changing objects: <t/b><uid>:<x>x<y>;...
    unsigned int token = 0; // 0 - nothing, 1 - tank, 2 - bullet
    size_t uid = 0;
    sf::Vector2i pos;
    TokenType tokenType = TokenType::None;
    for(size_t i = 0; i < changingObjects.size(); ++i) {

        char sym = changingObjects[i], nextSym = changingObjects[i + 1];
        if(token == 0) {

            if(sym == 't') {
                token = 1;
                tokenType = TokenType::Uid;
            } else if(sym == 'b') {
                token = 2;
                tokenType = TokenType::Uid;
            } else std::cout << "Warning! Unexpected token type ('" << sym << "'). It supposed to be either 't' or 'b'" << std::endl;

        } else {

            switch(tokenType) {
                case TokenType::Uid:
                    if(sym == ':') {
                        tokenType = TokenType::CoordX;
                    } else {
                        uid *= 10;
                        uid += sym - '0';
                    }
                    break;
                case TokenType::CoordX:
                    if(sym == 'x') {
                        tokenType = TokenType::CoordY;
                    } else if(sym == '-') {
                        RenderObjects& target = (token == 1 ? m_panzers : m_bullets);
                        RenderObjects::iterator found = target.find(uid);
                        if(found != target.end()) {
                            delete found->second;
                            token = 0;
                            target.erase(found);
                        } else std::cout << "Warning! Object with UID '" << uid << "' not found" << std::endl;
                        ++i; // Skip ';' and go to the next object
                    } else {
                        pos.x *= 10;
                        pos.x += sym - '0';
                    }
                    break;
                case TokenType::CoordY:
                    if(sym == ';' || nextSym == '\0') {

                        if(nextSym == '\0') {
                            pos.y *= 10;
                            pos.y += sym - '0';
                        }

                        tokenType = TokenType::None;
                        RenderObjects& target = (token == 1 ? m_panzers : m_bullets);
                        RenderObjects::iterator found = target.find(uid);
                        if(found != target.end()) {
                            found->second->setPosition(pos.x, pos.y);
                        } else {
                            RenderObject* tmp;
                            if(token == 1)
                                tmp = new Panzer;
                            else
                                tmp = new Bullet;
                            tmp->create(pos.x, pos.y, 1, 1);
                            target[uid] = tmp;
                            std::cout << "Add something" << std::endl;
                        }

                        token = 0;

                    } else {
                        pos.y *= 10;
                        pos.y += sym - '0';
                    }
                    break;
                default:
                    std::cout << "Warning! Unexpected token: " << static_cast<int>(tokenType) << std::endl;
            }

        }

    }

    return true;

}

void Mappy::resize(int width, int height) {
    sf::Vector2f ratio(width / m_mapSize.x, height / m_mapSize.y);
    float minSide = std::min(ratio.x, ratio.y);
    m_transform = sf::Transform::Identity;
    m_transform.translate((ratio.x - minSide) * m_mapSize.x * 0.5f, (ratio.y - minSide) * m_mapSize.y * 0.5f);
    m_transform.scale(minSide, minSide);
}

Mappy::~Mappy() {
    for(auto& item: m_bullets)
        delete item.second;
    for(auto& item: m_panzers)
        delete item.second;
    for(auto& item: m_obstacles)
        delete item;
    m_bullets.clear();
    m_panzers.clear();
    m_obstacles.clear();
}

void Mappy::moveToNextLine(sf::Vector2i& curPosition, const std::string& map, size_t& index) {
    if(map[index] == '\r' && map[index + 1] == '\n')
        ++index;
    ++curPosition.y;
    curPosition.x = 0;
}

void Mappy::draw(sf::RenderTarget& target, sf::RenderStates states) const {

    states.transform = m_transform;

    for(Obstacle* obstacle: m_obstacles)
        target.draw(*obstacle, states);

    for(const std::pair<size_t, RenderObject*>& panzer: m_panzers)
        target.draw(*panzer.second, states);

    for(const std::pair<size_t, RenderObject*>& bullet: m_bullets)
        target.draw(*bullet.second, states);

}
