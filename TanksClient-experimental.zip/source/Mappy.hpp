#ifndef MAPPY_HPP
#define MAPPY_HPP

#include <Objects.hpp>

#include <vector>
#include <map>

typedef std::map<size_t, RenderObject*> RenderObjects;

class Mappy : public sf::Drawable {
public:

    Mappy();

    // Map data is like: 1111[\r]\n1001[\r]\n1001[\r]\n1111[[\r]\n]
    bool loadMapFromData(const std::string& mapData);

    // Description of the changing objects: <t/b><uid>:(<x>x<y>/-);...
    //     where: b - bullet, t - tank, e.g.: t1027:1x1;t1028:5x1
    //     if "-" is present instead of coordinates - the tank has been destroyed
    bool applyChangingObjects(const std::string& changingObjects);

    void resize(int width, int height);

    ~Mappy();

private:

    enum class TokenType {
        None = 0,
        Uid,
        CoordX,
        CoordY
    };

    sf::Transform m_transform;
    sf::Vector2f m_mapSize;

    std::vector<Obstacle*> m_obstacles;
    RenderObjects m_bullets, m_panzers;

    void moveToNextLine(sf::Vector2i& curPosition, const std::string& map, size_t& index);
    void draw(sf::RenderTarget& target, sf::RenderStates states) const;

};

#endif // MAPPY_HPP
