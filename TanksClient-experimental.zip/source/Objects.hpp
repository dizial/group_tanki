#ifndef OBJECTS_HPP
#define OBJECTS_HPP

#include <SFML/Graphics.hpp>

/*
Rotations:
  2
1   3
  0
*/

class Object {
public:

    Object();
    virtual void create(int x, int y, int width, int height);

    void setPosition(int x, int y);

    ~Object();

protected:
    sf::RectangleShape m_shape;
};

class RenderObject : public Object, public sf::Drawable {
public:

    RenderObject();

    ~RenderObject();
};

class Obstacle : public RenderObject {
public:

    Obstacle();

    ~Obstacle();

private:
    void draw(sf::RenderTarget& target, sf::RenderStates states) const;
};

class UidContainer {
public:
    void setUid(size_t _uid) { uid = _uid; }
    size_t getUid() const { return uid; }
    bool isUid(size_t _uid) const { return _uid == uid; }
private:
    size_t uid = 0;
};

class Panzer : public RenderObject, public UidContainer {
public:

    Panzer();

    ~Panzer();

private:
    void draw(sf::RenderTarget& target, sf::RenderStates states) const;
};

class Bullet : public RenderObject, public UidContainer {
public:
    Bullet();
private:
    void draw(sf::RenderTarget& target, sf::RenderStates states) const;
};

#endif // OBJECTS_HPP
